# O Vigia — mod Fabric para Minecraft Java 26.2

## O que o mod faz

- **Primeiro spawn:** o jogador recebe o livro *O Vigia*, que traz um poema de terror. Na última página há o botão **[ CONCORDAR ]**.
- **Ao concordar:** o jogador fica com Escuridão e Lentidão II por 4 segundos. A partir daí, os eventos começam.
- **Evento da madeira:** ao quebrar um tronco, há 12% de chance de o Vigia aparecer logo atrás do bloco por 0,5 s. Esse evento tem um intervalo mínimo de 90 s entre uma aparição e outra.
- **Evento do vidro:** se houver vidro a até 6 blocos do jogador, o Vigia aparece do outro lado. Ele bate três vezes, quebra o vidro, corre atrás do jogador por 5 s e some.
- **Evento de longe:** o Vigia surge a 32–44 blocos, na frente do jogador. Se o jogador mirar a câmera nele, o jogador fica com Escuridão por 6 s, o Vigia corre atrás dele e some ao fim dos 6 s. Se ninguém olhar para ele em 60 s, ele some sozinho.
- Os eventos do vidro e de longe se alternam e acontecem a cada 3 a 7 minutos.
- As aparições dos eventos não levam dano. O Vigia invocado por comando é um monstro normal, com 20 corações e 2,5 corações de dano por golpe.

## Comandos

| Comando | Quem pode usar | O que faz |
|---|---|---|
| `/summon vigia:vigia` | operador | Invoca o Vigia como monstro hostil |
| `/vigia livro` | todos | Dá outra cópia do livro |
| `/vigia concordar` | todos | O mesmo que clicar no botão do livro |
| `/vigia evento madeira`, `/vigia evento vidro` e `/vigia evento longe` | operador | Força o evento na hora (para testar) |
| `/vigia resetar` | operador | Desfaz o trato. Ao entrar de novo no mundo, você recebe o livro outra vez |

## Como compilar (gerar o .jar)

**Opção A — no seu computador**
1. Instale o **JDK 25**. Por exemplo, o Temurin 25 em https://adoptium.net
2. Abra o terminal na pasta do projeto e rode:
   - Windows: `gradlew.bat build`
   - Mac/Linux: `./gradlew build`
3. A primeira vez demora, porque o Gradle baixa o Minecraft e o Fabric. O mod pronto fica em `build/libs/vigia-1.0.0.jar`. Use esse arquivo, não o que termina em `-sources`.

**Opção B — sem instalar nada (GitHub)**
1. Crie um repositório no GitHub e envie todos os arquivos desta pasta, incluindo a pasta `.github`.
2. Abra a aba **Actions**. Quando o build ficar verde, baixe o arquivo **Artifacts**. O `.jar` estará dentro dele.

## Como instalar

1. Instale o **Fabric Loader** para a 26.2 (https://fabricmc.net/use).
2. Coloque na pasta `mods` dois arquivos: o `vigia-1.0.0.jar` e a **Fabric API** para a 26.2 (versão 0.161.0+26.2 ou mais nova).

## Para ajustar

Os números de chance, intervalo e duração ficam no topo de `VigiaEvents.java` e de `VigiaEntity.java`. A textura fica em `src/main/resources/assets/vigia/textures/entity/vigia.png` e tem 64×64 pixels, no mesmo molde de uma skin de jogador. Dá para trocar pela sua.

Os eventos não acontecem na dificuldade Pacífica, porque o jogo remove monstros nesse modo.
